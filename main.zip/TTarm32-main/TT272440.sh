#!/bin/sh

#PJ小宇
#甜糖邀请码272440

cd /root

rm -f main.zip

cd /root

rm -f 272440.sh

cd /root

rm -f xy.sh

cd /root

rm -f dns.sh

cd /root

rm -rf /usr/node

cd /.

mkdir mnts /usr/node

chmod -R 777 /root/TTarm32-main

cd /root/TTarm32-main

/bin/cp -rf node/*  /usr/node

cd /root/TTarm32-main

/bin/cp -rf 272440/*  /root

cd /usr

chmod -R 777 /usr/node

cd /root/TTarm32-main

/bin/cp -rf etc/*  /etc

cd /.

sh 272440.sh

cd /root

rm -f main.zip

cd /root

rm -rf /root/TTarm32-main&&

echo "\033[31m  恭喜你，甜糖已经成功启动！新人填写甜糖邀请码：272440即可获得15张加成卡。你的支持是我的动力---@PJ小宇 \033[1m"
echo "   Congratulations, Tiantang has been started successfully! New people fill in Tiantang invitation code: 272440 can get 15 bonus cards. Your support is my driving force----@PJxiaoyu"
echo "   如需帮助可加入甜糖QQ群:739975071 或咨询QQ:898811295"

